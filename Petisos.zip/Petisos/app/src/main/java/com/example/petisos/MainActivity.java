package com.example.petisos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edUsuarioIni, edContrasIni;
    private Button btBorrarIni, btIngresarIni, btRegistrIni;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edUsuarioIni = findViewById(R.id.edUsuario);
        edContrasIni = findViewById(R.id.edContraseña);
        btBorrarIni = findViewById(R.id.btBorrar);
        btIngresarIni = findViewById(R.id.btIngresar);
        btRegistrIni = findViewById(R.id.btRegistrar);

    }

    public void registrar(View view){
        Intent reg =new Intent(MainActivity.this, Registro.class);
        startActivity(reg);
    }

    public void borrar(View view){
        Toast.makeText(MainActivity.this, "Borrado", Toast.LENGTH_LONG).show();
    }
}