package com.example.petisos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.petisos.BaseDatos.CRUD_Petisos;

public class Registro extends AppCompatActivity {

    private EditText edUsuarioReg, edCorreoReg, edContrasReg1, edContrasReg2;
    private Button btAtrasReg, btSiguiReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        edUsuarioReg = findViewById(R.id.edUsuarioRegistro);
        edCorreoReg = findViewById(R.id.edCorreoRegistro);
        edContrasReg1 = findViewById(R.id.edContraseña1Registro);
        edContrasReg2 = findViewById(R.id.edContraseña2Registro);
        btAtrasReg = findViewById(R.id.btAtrasRegistro);
        btSiguiReg = findViewById(R.id.btSigueRegistro);

    }

    public void regresarRegistro(View view){
        Intent atrReg = new Intent(Registro.this, MainActivity.class);
        startActivity(atrReg);
    }

    public void SiguirRegistro(View view){
        try {
            String usua = edUsuarioReg.getText().toString();
            String corr = edCorreoReg.getText().toString();
            String cont1 = edContrasReg1.getText().toString();
            String cont2 = edContrasReg2.getText().toString();
            Log.d("pw", cont1 + " / " + cont2);
            if(cont1.equals(cont2)){
                Intent sigReg = new Intent(Registro.this, RegistroMascota.class);
                sigReg.putExtra("usuario", usua);
                sigReg.putExtra("correo", corr);
                sigReg.putExtra("contraseña", cont1);
                startActivity(sigReg);
            } else {
                Toast.makeText(Registro.this, "Las contraseñas son diferentes, intente de nuevo", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception ex) {
            Toast.makeText(Registro.this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
        }
    }
}