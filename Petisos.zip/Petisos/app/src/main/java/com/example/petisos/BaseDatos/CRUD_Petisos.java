package com.example.petisos.BaseDatos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import java.sql.SQLData;

public class CRUD_Petisos extends BDConexion{

    private Context context;

    public CRUD_Petisos(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public void agregar(String nombre, String correo, String contraseña){
        try {
            BDConexion bdConexion = new BDConexion(context);
            SQLiteDatabase db = bdConexion.getWritableDatabase();
            ContentValues datos = new ContentValues();
            datos.put("nombre", nombre);
            datos.put("correo", correo);
            datos.put("contraseña", contraseña);
            db.insert(DATABASE_TABLE_NAME, null, datos);
        } catch (Exception ex){
            ex.toString();
        }
    }

    public String consultar(String id){
        try {
            BDConexion bdConexion = new BDConexion(context);
            SQLiteDatabase db = bdConexion.getWritableDatabase();
            Cursor cursorUsuarios = null;
            cursorUsuarios = db.rawQuery("SELECT from " + DATABASE_TABLE_NAME + " WHERE id = '" +
                    id + "'", null);
            if(cursorUsuarios.moveToFirst()){
                String nombre = cursorUsuarios.getString(1);
                String correo = cursorUsuarios.getString(2);
                String contraseña = cursorUsuarios.getString(3);
                return nombre + "," + correo + "," + contraseña;
            }
        } catch (Exception ex){
            ex.toString();
        }
        return null;
    }

    public void actualizar(String id, String nombre, String correo, String contraseña){
        try {
            BDConexion bdConexion = new BDConexion(context);
            SQLiteDatabase db = bdConexion.getWritableDatabase();
            ContentValues datos = new ContentValues();
            datos.put("nombre", nombre);
            datos.put("correo", correo);
            datos.put("contraseña", contraseña);
            db.update(DATABASE_TABLE_NAME, datos, "id = ?", new String[] {id});
        } catch (Exception ex){
            ex.toString();
        }
    }

    public void eliminar(String id){
        try {
            BDConexion bdConexion = new BDConexion(context);
            SQLiteDatabase db = bdConexion.getWritableDatabase();
            db.delete(DATABASE_TABLE_NAME, "id = ?", new String[] {id});
        } catch (Exception ex){
            ex.toString();
        }
    }
}
