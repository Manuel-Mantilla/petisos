package com.example.petisos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.petisos.BaseDatos.CRUD_Petisos;

public class RegistroMascota extends AppCompatActivity {

    private Spinner spClaseMasc;
    private EditText edRazaMasc, edNombreMasc, edFechaNacMasc;
    private Button btAtrasMasc, btGuardaMasc;
    private static CRUD_Petisos crud;
    private static String usuario, correo, contraseña;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_mascota);

        spClaseMasc = findViewById(R.id.spClaseMascota);
        edRazaMasc = findViewById(R.id.edRazaMascota);
        edNombreMasc = findViewById(R.id.edNombreMascota);
        edFechaNacMasc = findViewById(R.id.edFechaNacMascota);
        btAtrasMasc = findViewById(R.id.btAtrasRegMascota);
        btGuardaMasc = findViewById(R.id.btGuarRegMascota);

        usuario = getIntent().getStringExtra("usuario");
        correo = getIntent().getStringExtra("correo");
        contraseña = getIntent().getStringExtra("contraseña");

        crud = new CRUD_Petisos(RegistroMascota.this);
        SQLiteDatabase db = crud.getWritableDatabase();
        if(db != null){
            Toast.makeText(RegistroMascota.this, "Base de datos creada", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(RegistroMascota.this, "Error al crear base de datos", Toast.LENGTH_SHORT).show();
        }
    }

    public void regresarRegMasc(View view){
        Intent atrRegM = new Intent(RegistroMascota.this, Registro.class);
        startActivity(atrRegM);
    }

    public void guardarRegMasc(View view){
        try {
            crud.agregar(usuario, correo, contraseña);

            Toast.makeText(RegistroMascota.this, "Registro satisfactorio", Toast.LENGTH_SHORT).show();
        } catch (Exception ex){
            Toast.makeText(RegistroMascota.this, "Error al crear registro", Toast.LENGTH_SHORT).show();
        }
    }
}